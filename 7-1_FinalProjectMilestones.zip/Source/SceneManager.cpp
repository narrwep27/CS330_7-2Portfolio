///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  CreateBlendedGLTexture()
 *
 *  Loads background and foreground image to create single combined texture
 ***********************************************************/
bool SceneManager::CreateOverlaidGLTexture(const char* bgFile, const char* fgFile, std::string tag, float fgOpacity)
{
	int bgWidth = 0, bgHeight = 0, bgChannels = 0,
		fgWidth = 0, fgHeight = 0, fgChannels = 0;
	GLuint textureId = 0;

	stbi_set_flip_vertically_on_load(true);

	// load two images
	unsigned char* background = stbi_load(bgFile, &bgWidth, &bgHeight, &bgChannels, 4);
	unsigned char* foreground = stbi_load(fgFile, &fgWidth, &fgHeight, &fgChannels, 4);

	// free memory if at least 1 image failed to load
	if (!background || !foreground)
	{
		if (background) stbi_image_free(background);
		if (foreground) stbi_image_free(foreground);
		
		return false;
	}

	// map textures onto one another
	std::vector<unsigned char> composited(bgWidth * bgHeight * 4);
	for (int y = 0; y < bgHeight; y++)
	{
		for (int x = 0; x < bgWidth; x++)
		{
			int destInd = (y * bgWidth + x) * 4;
			int srcX = (fgWidth == bgWidth) ? x : (x * fgWidth / bgWidth),
				srcY = (fgHeight == bgHeight) ? y : (y * fgHeight / bgHeight),
				srcInd = (srcY * fgWidth + srcX) * 4;

			float fgAlpha = (foreground[srcInd + 3] / 255.0f) * fgOpacity;

			for (int c = 0; c < 3; c++)
			{
				composited[destInd + c]
					= (unsigned char)(foreground[srcInd + c] * fgAlpha + background[destInd + c] * (1.0f - fgAlpha));
			}
			composited[destInd + 3] = 255;
		}
	}

	glGenTextures(1, &textureId);
	glBindTexture(GL_TEXTURE_2D, textureId);

	// texture wrapping
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// texture filtering
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, bgWidth, bgHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, composited.data());
	// generate the texture mipmaps for mapping textures to lower resolutions
	glGenerateMipmap(GL_TEXTURE_2D);

	// free memory
	stbi_image_free(background);
	stbi_image_free(foreground);
	glBindTexture(GL_TEXTURE_2D, 0); // unbind texture

	// register the loaded texture and associate it with the special tag string
	m_textureIDs[m_loadedTextures].ID = textureId;
	m_textureIDs[m_loadedTextures].tag = tag;
	m_loadedTextures++;

	return true;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
  *  DefineObjectMaterials()
  *
  *  This method is used for configuring the various material
  *  settings for all of the objects within the 3D scene.
  ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// define material that define model texture
	OBJECT_MATERIAL grayMaterial;
	grayMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	grayMaterial.ambientStrength = 0.1f;
	grayMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	grayMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	grayMaterial.shininess = 2;
	grayMaterial.tag = "gray";
	m_objectMaterials.push_back(grayMaterial);

	// wood material for table plane mesh
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
	woodMaterial.ambientStrength = 0.2f;
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
	woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	woodMaterial.shininess = 0.3;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// plastic material for the remote control body
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.ambientColor = glm::vec3(0.15f, 0.15f, 0.15f);
	plasticMaterial.ambientStrength = 0.25f;
	plasticMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
	plasticMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
	plasticMaterial.shininess = 35.0f;
	plasticMaterial.tag = "plastic";
	m_objectMaterials.push_back(plasticMaterial);

	// rubber/silicone material for the remote control buttons
	OBJECT_MATERIAL rubberMaterial;
	rubberMaterial.ambientColor = glm::vec3(0.05f, 0.05f, 0.05f);
	rubberMaterial.ambientStrength = 0.3f;
	rubberMaterial.diffuseColor = glm::vec3(0.15f, 0.15f, 0.15f);
	rubberMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	rubberMaterial.shininess = 2.0f;
	rubberMaterial.tag = "rubber";
	m_objectMaterials.push_back(rubberMaterial);

	// felt/plush material for the soccer ball
	OBJECT_MATERIAL feltMaterial;
	feltMaterial.ambientColor = glm::vec3(0.25f, 0.25f, 0.25f);
	feltMaterial.ambientStrength = 0.3f;
	feltMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	feltMaterial.specularColor = glm::vec3(0.02f, 0.02f, 0.02f);
	feltMaterial.shininess = 1.0f;
	feltMaterial.tag = "felt";
	m_objectMaterials.push_back(feltMaterial);

	// paper/plastic tag material for the soccer ball tag
	OBJECT_MATERIAL tagMaterial;
	tagMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
	tagMaterial.ambientStrength = 0.25f;
	tagMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f);
	tagMaterial.specularColor = glm::vec3(0.15f, 0.15f, 0.15f);
	tagMaterial.shininess = 10.0f;
	tagMaterial.tag = "tag";
	m_objectMaterials.push_back(tagMaterial);

	// silver metal material for the ring
	OBJECT_MATERIAL silverMaterial;
	silverMaterial.ambientColor = glm::vec3(0.23f, 0.23f, 0.23f);
	silverMaterial.ambientStrength = 0.2f;
	silverMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	silverMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	silverMaterial.shininess = 51.2f;
	silverMaterial.tag = "silver";
	m_objectMaterials.push_back(silverMaterial);

	// glass material - minimal diffuse/ambient so color comes mostly
	// from the sharp, bright specular highlight
	OBJECT_MATERIAL glassMaterial;
	glassMaterial.ambientColor = glm::vec3(0.05f, 0.05f, 0.05f);
	glassMaterial.ambientStrength = 0.1f;
	glassMaterial.diffuseColor = glm::vec3(0.1f, 0.1f, 0.1f);
	glassMaterial.specularColor = glm::vec3(0.95f, 0.95f, 0.95f);
	glassMaterial.shininess = 90.0f;
	glassMaterial.tag = "glass";
	m_objectMaterials.push_back(glassMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// configure 1st light source positioned above the scene
	m_pShaderManager->setVec3Value("lightSources[0].position", 0.0f, 5.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 30.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.4f);

	// configure 2nd light source positioned to the far-right
	m_pShaderManager->setVec3Value("lightSources[1].position", 6.0f, 1.0f, 6.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 30.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.4f);

	// configure the 3rd light source positioned to the far-left
	m_pShaderManager->setVec3Value("lightSources[2].position", -6.0f, 1.0f, 6.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 30.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.4f);

	// configure the 4th light source positioned towards the start position of the camera
	m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, 1.0f, -6.0f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.3f, 0.3f, 0.3f);
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.2f, 0.2f, 0.2f);
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 30.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.4f);

	m_pShaderManager->setBoolValue(g_UseLightingName, true);
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

 /***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	// load rusticwood.jpg image as texture
	bReturn = CreateGLTexture("textures/rusticwood.jpg", "rusticwood");
	// load carbon-fiber.png image as texture
	bReturn = CreateGLTexture("textures/carbon-fiber.png", "carbon-fiber");
	// load green-background.jpg image as texture
	bReturn = CreateGLTexture("textures/green-background.jpg", "green-background");
	// load gray-screen.jpg as background and yes.png as foreground in combined texture
	bReturn = CreateOverlaidGLTexture("textures/gray-screen.jpg", "textures/yes.png", "gray-bg-yes-fg");
	// load soccer-ball.png image as texture
	bReturn = CreateGLTexture("textures/soccer-ball.png", "soccer-ball");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the textures for the 3D scene
	LoadSceneTextures();
	// define the materials for objects in the scene
	DefineObjectMaterials();
	// add and define the light sources for the scene
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh(0.12f);
	m_basicMeshes->LoadSphereMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderTablePlane();
	RenderRemote();
	RenderBottle();
	RenderBall();
	RenderRing();
}

void SceneManager::RenderTablePlane()
{
	// declare and set the variables for the transformations of plane mesh
	glm::vec3 scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f); // XYZ scale
	float XrotationDegrees = 0.0f, // X rotation
		YrotationDegrees = 0.0f, // Y rotation
		ZrotationDegrees = 0.0f; // Z rotation
	glm::vec3 positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f); // XYZ position

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("rusticwood"); // apply rusticwood texture to plane mesh
	SetShaderMaterial("wood"); // apply wood material color reflectivity to plane mesh

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
}

void SceneManager::RenderRemote()
{
	// declare variables for the remote model transformations
	glm::vec3 scaleXyz = glm::vec3(10.0, 1.0, 1.7); // XYZ scale
	float xRotationDeg = 0.0, // X rotation
		yRotationDeg = -40.0, // Y rotation
		zRotationDeg = 0.0; // Z rotation
	glm::vec3 positionXyz = glm::vec3(-5.3, 0.55, 6.6); // XYZ position

	// set the transformations into memory to be used on the box base mesh
	SetTransformations(scaleXyz, xRotationDeg, yRotationDeg, zRotationDeg, positionXyz);
	
	/*
	* Idea for this texture is to attempt to put text on the remote model similar to how
	* there is text on the actual remote control. I added the text in the form of a texture.
	*/
	SetShaderTexture("gray-bg-yes-fg"); // set texture of box base mesh
	SetTextureUVScale(10.0f, 2.0f); // tile texture 10 x 2
	SetShaderMaterial("plastic"); // apply plastic material reflectivity to remote control body

	m_basicMeshes->DrawBoxMesh(); // draw the box base mesh

	// revert tiling to 1 x 1
	SetTextureUVScale(1.0f, 1.0f);

	/*
	* There are 3 sections of buttons.
	* - 1st section has 2 columns of 4 rows: 8 buttons
	* - 2nd section has 1 single, large button
	* - 3rd section has 2 columns of 5 rows: 10 buttons
	* 
	* Buttons are identified by its section, column, and row separated by periods
	* Ex: the green power button is 1.2.1 (section 1, column 2, row 1)
	*/

	// x, y, and z rotations for all remote control buttons will be 0
	yRotationDeg = 0.0; // x and z rotation are already 0, so no need to set them here

	// set the scale and position for power button (1.2.1) mesh
	scaleXyz = glm::vec3(0.25, 0.2, 0.25);
	positionXyz = glm::vec3(-8.2, 0.95, 3.6);

	// set transformations into memory to be used on power button (1.2.1) mesh
	SetTransformations(scaleXyz, xRotationDeg, yRotationDeg, zRotationDeg, positionXyz);
	// set texture of power button (1.2.1) mesh
	SetShaderTexture("green-background");
	// apply rubber material reflectivity to remote control buttons
	SetShaderMaterial("rubber");
	// draw power button (1.2.1) mesh
	m_basicMeshes->DrawCylinderMesh();

	// set texture for the remaining buttons
	SetShaderTexture("carbon-fiber");

	// set the scale and position for large volume button (2.1.1) mesh
	scaleXyz = glm::vec3(0.5, 0.2, 0.5);
	positionXyz = glm::vec3(-6.0, 0.95, 5.9);

	// set transformations into memory to be used on large volume button (2.1.1) mesh
	SetTransformations(scaleXyz, xRotationDeg, yRotationDeg, zRotationDeg, positionXyz);
	// draw large volume button (2.1.1) mesh
	m_basicMeshes->DrawCylinderMesh();

	// draw buttons 1.1.1, 1.1.2, 1.1.2, 1.1.4
	PositionAndRenderRemoteBtns(4, glm::vec3(-8.65, 0.95, 4.15));
	// draw buttons 1.2.2, 1.2.3 1.2.4
	PositionAndRenderRemoteBtns(3, glm::vec3(-7.6, 0.95, 4.1));
	// draw buttons 3.1.1, 3.1.2, 3.1.3, 3.1.4, 3.1.5
	PositionAndRenderRemoteBtns(5, glm::vec3(-5.3, 0.95, 6.95));
	// draw buttons 3.2.1, 3.2.2, 3.2.3, 3.2.4, 3.2.5
	PositionAndRenderRemoteBtns(5, glm::vec3(-4.9, 0.95, 6.45));
}

void SceneManager::PositionAndRenderRemoteBtns(unsigned int count, glm::vec3 origin)
{
	// scale and position step will be equal for all buttons
	const glm::vec3 scaleXyz = glm::vec3(0.15, 0.2, 0.15),
		positionStep = glm::vec3(0.53, 0, 0.45);
	// Loop `count` times, 1 loop per button that will be rendered
	for (unsigned int i = 0; i < count; ++i)
	{
		// Set position for current button by adding step value * button index to origin
		glm::vec3 positionXyz = origin + (positionStep * static_cast<float>(i));
		// Set transformations into memory for button index
		SetTransformations(scaleXyz, 0, 0, 0, positionXyz);

		// Draw button index
		m_basicMeshes->DrawCylinderMesh();
	}
}

void SceneManager::RenderBottle()
{
	/* bottle base */
	// declare variables for glass bottle model transformation
	glm::vec3 scaleXyz = glm::vec3(3.0f, 11.0f, 3.0f),
		positionXyz = glm::vec3(5.0f, 0.05f, -0.8f);
	const float rotation = 0.0f;

	// set transformation values into memory to be used on the cylinder mesh
	SetTransformations(scaleXyz, rotation, rotation, rotation, positionXyz);
	// set green glass color
	SetShaderColor(0.2f, 0.5f, 0.2f, 0.65f);
	// set glass texture
	SetShaderMaterial("glass");

	// draw cylinder/bottle base mesh
	m_basicMeshes->DrawCylinderMesh();

	/* bottle neck */
	// set position and scale of 1st tapered cylinder mesh (neck, lower segment)
	positionXyz += glm::vec3(0.0f, scaleXyz.y, 0.0f);
	scaleXyz += glm::vec3(0.0f, -5.0f, 0.0f);
	SetTransformations(scaleXyz, rotation, rotation, rotation, positionXyz);

	// draw 1st tapered cylinder/bottle neck mesh
	m_basicMeshes->DrawTaperedCylinderMesh();

	// set position and scale of 2nd tapered cylinder mesh (neck, upper segment)
	positionXyz += glm::vec3(0.0f, scaleXyz.y, 0.0f);
	scaleXyz = glm::vec3(scaleXyz.x / 2, 4.0f, scaleXyz.z / 2);
	SetTransformations(scaleXyz, rotation, rotation, rotation, positionXyz);

	// draw 2nd tapered cylinder/bottle neck mesh
	m_basicMeshes->DrawTaperedCylinderMesh();

	/* bottle lower lip */
	// set position and scale of base of lower lip
	positionXyz += glm::vec3(0.0f, scaleXyz.y, 0.0f);
	scaleXyz = glm::vec3(scaleXyz.x / 2 + 0.2, 1.3f, scaleXyz.z / 2 + 0.2);
	SetTransformations(scaleXyz, rotation, rotation, rotation, positionXyz);

	// draw lower lip cylinder
	m_basicMeshes->DrawCylinderMesh();

	// set position and scale of tip of lower lip
	positionXyz += glm::vec3(0.0f, scaleXyz.y, 0.0f);
	scaleXyz += glm::vec3(0.0f, -1.0f, 0.0f);
	SetTransformations(scaleXyz, rotation, rotation, rotation, positionXyz);

	// draw lower lip tip
	m_basicMeshes->DrawTaperedCylinderMesh();

	/* bottle upper lip */
	positionXyz += glm::vec3(0.0f, scaleXyz.y - 0.2f, 0.0f);
	scaleXyz += glm::vec3(0.0f, 0.06f, 0.0f);
	SetTransformations(scaleXyz, rotation, rotation, rotation, positionXyz);

	// draw upper lip
	m_basicMeshes->DrawCylinderMesh();

	positionXyz += glm::vec3(0.0f, scaleXyz.y, 0.0f);
	scaleXyz += glm::vec3(0.0f, -0.26f, 0.0f);
	SetTransformations(scaleXyz, rotation, rotation, rotation, positionXyz);

	m_basicMeshes->DrawTaperedCylinderMesh();
}

void SceneManager::RenderBall()
{
	// declare variables for soccer ball model transofrmations
	glm::vec3 scaleXyz = glm::vec3(3.8f, 3.8f, 3.8f), // XYZ vector scale
		positionXyz = glm::vec3(-4.5f, 3.8f, -1.0f); // XYZ vector position
	float xRot = 0.0f, // X rotation degrees
		yRot = 0.0f, // Y rotation degrees
		zRot = 0.0f; // Z rotation degrees

	// set transformation values into memory to be used on the sphere mesh
	SetTransformations(scaleXyz, xRot, yRot, zRot, positionXyz);
	// set soccer ball texture
	SetShaderTexture("soccer-ball");
	// set soccer ball material
	SetShaderMaterial("felt");

	// draw sphere/soccer ball mesh
	m_basicMeshes->DrawSphereMesh();

	// set variables for ball tag model transformations
	scaleXyz = glm::vec3(3.7f, 0.04f, 1.5f),
		positionXyz = glm::vec3(-1.6f, 0.7f, 1.5f);
	yRot = 140.0f;

	// set transformations, color, and object material
	SetTransformations(scaleXyz, xRot, yRot, zRot, positionXyz);
	SetShaderColor(0.7f, 0.7f, 0.7f, 1.0f);
	SetShaderMaterial("tag");
	m_basicMeshes->DrawBoxMesh(); // draw box/ball tag mesh
}

void SceneManager::RenderRing()
{
	// declare variables for metal ring model transofrmations
	const glm::vec3 scaleXyz = glm::vec3(0.5f, 0.5f, 1.2f), // XYZ vector scale
		positionXyz = glm::vec3(0.0f, 0.15f, 5.0f); // XYZ vector position
	const float xRot = 90.0f, // X rotation degrees
		yRot = 0.0f, // Y rotation degrees
		zRot = 0.0f; // Z rotation degrees

	// set transformation values into memory to be used on the torus mesh
	SetTransformations(scaleXyz, xRot, yRot, zRot, positionXyz);
	// set metal ring color
	SetShaderColor(0.35f, 0.35f, 0.35f, 1.0f);
	// set metal ring material
	SetShaderMaterial("silver");

	// draw torus/ring mesh
	m_basicMeshes->DrawTorusMesh();
}
